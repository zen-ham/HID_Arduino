
# How to use Controller with Zelesis on a Steam or Non Steam Game (eg Fortnite, etc)


## Initial Set up
**First have Steam and Zelesis Installed, Have your Zelesis Target button to LMB (Or what ever button you want the aimbot to be triggered with)**\
![App Screenshot](https://i.imgur.com/wtuTqFi.png)

**Connect your controller and you will be able to access steam inputs, Navigate to the "Triggers" tab and add a second command using the gear icon. Lastly add the button you set as your target button as the second command for the Right Trigger**\
![App Screenshot](https://i.imgur.com/XcuXQvo.png)

## Setup for Non Steam Games
**When you open steam on the bottom left there should be a button that says "Add a Game" (This tutorial will show you how to add epicgames to steam)**\
![App Screenshot](https://i.imgur.com/xueTgXR.png)

**Then click "Add None Steam Game"** \
![App Screenshot](https://i.imgur.com/W5hhYPk.png)

**Browse the Apps shown but epic games usually isn't on here so you will need to click "Browse" on the bottom left.**\
![App Screenshot](https://i.imgur.com/KSlh9qm.png)

**You will have to find the path for the launcher which you will see in the screenshot below**\
![App Screenshot](https://i.imgur.com/hMoFa6A.png)

**Click the Epic Games Launcher and add it to steam, if all went well it should look like this**\
![App Screenshot](https://i.imgur.com/7xlsOsS.png)

## Usage
**When wanting to use zelesis on non steam games, eg. Fortnite. You must always open Epicgames from steam. Make sure Epic games is not running in the background. To fix this press Ctrl+Shift+Esc and search for epic games and end the task.**

**When you Open Epic games through steam, you can now open fortnite and your steam input should work. Now when you shoot with your controller it will also track the enemy since zelesis Aimbot button is being triggered**

> [!NOTE]
> This method will work for Any non steam games. COD does not work due to them blocking mouse inputs while using a controller, For now its not possible with this method to use zelesis on controller when playing COD, but you can use some other software like rewasd which will work.